"""CheckEmailMixin — native tool check_email."""

import imaplib
import logging
from typing import Any

from backend.agent.utils.contract import make_error_response, make_success_response, zero_usage
from backend.agent.utils.email_accounts import resolve_account
from backend.agent.utils.email_parser import is_older_than, parse_email, parse_relative_date
from backend.agent.utils.error_logger import log_error

logger = logging.getLogger(__name__)


class CheckEmailMixin:
    """Native tool ``check_email``: check the IMAP mailbox for unseen emails."""
    async def check_email(self, account: str, folder: str = "INBOX", sender: str | None = None, date: str = "1h", mark_read: bool = False) -> dict[str, Any]:
            """Check the IMAP mailbox for unseen emails and return them parsed.

            Connects via IMAP (SSL), searches for UNSEEN messages in the given
            folder (optionally filtered by sender and age), parses each one, and
            returns the structured results. This is a one-shot check — no polling
            loop. The agent calls this tool on demand; it does not run in the
            background. Accounts are stored encrypted in DB, never in ``.env``.

            Args:
                account: Alias or email address of the configured account
                    (required). Use the exact alias shown in
                    Configuración → Mails (e.g. ``"Servicios"``) or the full
                    email address. Never pass an IMAP folder here.
                folder: IMAP folder to check (default ``"INBOX"``).
                sender: Optional sender address to filter UNSEEN messages.
                date: Relative age filter: ``1h``-``23h`` (hours), ``<n>d``
                    (days), ``<n>m`` (months), ``<n>y`` (years) or ``all``
                    (no date filter). Default ``"1h"``.
                mark_read: When ``True`` fetched messages are marked as read.
                    When ``False`` (default) they are peeked (``BODY.PEEK[]``)
                    and stay unseen.

            Returns:
                dict with ``{status, message, data, usage}``.
                ``data`` contains cleaned text with one line per email
                (``date | sender | subject``) when there are any,
                or the text ``"No hay mails pendientes"`` when there are none.

            Raises:
                No exception escapes: every failure is returned as an error
                contract dict.
            """
            try:
                cutoff, date_error = parse_relative_date(date)
                if date_error:
                    return make_error_response(
                        message=date_error,
                        usage=zero_usage(),
                    )

                if not (account or "").strip():
                    from backend.agent.utils.email_accounts import list_accounts

                    available = [a.get("alias", "") for a in list_accounts()]
                    hint = f" Cuentas disponibles: {', '.join(available)}." if available else ""
                    return make_error_response(
                        message=(
                            "Falta el parámetro 'account' (alias o email, requerido)."
                            f"{hint} Nunca uses una carpeta IMAP como cuenta."
                        ),
                        usage=zero_usage(),
                    )
                creds = resolve_account(account)
                if creds is None:
                    return make_error_response(
                        message=(
                            "No hay cuentas de mail configuradas. "
                            "Cargá mail + password + alias opcional desde Configuración → Mails."
                        ),
                        usage=zero_usage(),
                    )
                server = creds.get("imap_server", "")
                port = int(creds.get("imap_port", 993))
                user = creds.get("email", "")
                password = creds.get("password", "")

                if not all([server, user, password]):
                    return make_error_response(
                        message="Cuenta de mail incompleta en DB.",
                        usage=zero_usage(),
                    )

                mail = imaplib.IMAP4_SSL(server, port, timeout=15)
                try:
                    mail.login(user, password)
                    typ_select, _ = mail.select(folder)
                    if typ_select != "OK":
                        return make_error_response(
                            message=f"No se pudo seleccionar la carpeta '{folder}'.",
                            usage=zero_usage(),
                        )

                    since = f' SINCE {cutoff.strftime("%d-%b-%Y")}' if cutoff else ""
                    if sender:
                        search_criteria = f'(UNSEEN{since} FROM "{sender}")'
                    else:
                        search_criteria = f"(UNSEEN{since})"

                    typ, data = mail.search(None, search_criteria)
                    if typ != "OK" or not data or not data[0]:
                        return make_success_response(
                            message="No hay mensajes no leidos.",
                            data="No hay mails pendientes",
                            usage=zero_usage(),
                        )

                    msg_ids = data[0].split()
                    results: list[dict] = []
                    fetch_part = "(BODY[])" if mark_read else "(BODY.PEEK[])"
                    for msg_id in msg_ids:
                        try:
                            typ_fetch, fetch_data = mail.fetch(msg_id, fetch_part)
                            if typ_fetch != "OK" or not fetch_data:
                                continue
                            raw_email = None
                            for item in fetch_data:
                                if isinstance(item, tuple):
                                    raw_email = item[1]
                                    break
                            if not raw_email:
                                continue
                            parsed = parse_email(raw_email)
                            if cutoff and is_older_than(parsed.get("date_parsed"), cutoff):
                                continue
                            results.append({
                                "message_id": parsed.get("message_id", ""),
                                "sender": parsed.get("sender", ""),
                                "subject": parsed.get("subject", ""),
                                "date": parsed.get("date", ""),
                                "date_local": parsed.get("date_local", ""),
                                "body": parsed.get("body", ""),
                                "attachments": [
                                    a.get("filename", "")
                                    for a in parsed.get("attachments", [])
                                ],
                            })
                        except Exception as e:
                            logger.warning("Error procesando mail %s: %s", msg_id, e)
                            log_error(str(e), source="tools.py:check_email")
                            continue
                finally:
                    try:
                        mail.logout()
                    except Exception as e:
                        log_error(str(e), source="tools.py:check_email(logout)")
                        pass

                lines = [
                    f"{r.get('date_local') or r.get('date')} | {r.get('sender')} | {r.get('subject')}"
                    for r in results
                ]
                text = "\n".join(lines)
                return make_success_response(
                    message=f"{len(results)} mensaje(s) no leido(s) encontrado(s).",
                    data=text if text else "No hay mails pendientes",
                    usage=zero_usage(),
                )
            except Exception as e:
                logger.exception("Error in check_email: %s", e)
                return make_error_response(
                    message=f"Error checking email: {e}",
                    usage=zero_usage(),
                )
