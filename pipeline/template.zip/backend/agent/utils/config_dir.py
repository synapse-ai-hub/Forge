"""Configuration directory management for synapseForge.

Provides a single source of truth for the user config directory:
~/.config/synapseForge/

Structure:
~/.config/synapseForge/
├── skills/           # User skills (SKILL.md in subdirs)
├── tools/            # External tools (.py files)
├── agents/           # Agent definitions (.md files)
├── knowledge/        # Chroma vector store collections
├── workspace/        # Working folders of the workflows (one per workflow)
└── config.json       # Main config (MCP, UI prefs, etc.)
"""

from __future__ import annotations

import json
import logging
import os
import sys
from contextvars import ContextVar
from pathlib import Path
from typing import Any

_current_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(os.path.dirname(_current_dir))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from backend.agent.utils.error_logger import log_error

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Config directory path
# ---------------------------------------------------------------------------

def get_config_dir() -> Path:
    """Return the synapseForge config directory path.

    Creates the directory if it doesn't exist.

    Returns:
        Path to ~/.config/synapseForge/ (consistent across Windows, Linux, macOS)
    """
    # Use ~/.config/synapseForge on all platforms (like opencode)
    base = Path(os.getenv("XDG_CONFIG_HOME", Path.home() / ".config"))
    config_dir = base / "synapseForge"
    config_dir.mkdir(parents=True, exist_ok=True)

    # Ensure subdirectories exist
    (config_dir / "skills").mkdir(exist_ok=True)
    (config_dir / "tools").mkdir(exist_ok=True)
    (config_dir / "agents").mkdir(exist_ok=True)
    (config_dir / "knowledge").mkdir(exist_ok=True)

    return config_dir


def ensure_config_dir() -> Path:
    """Ensure config directory and subdirectories exist.

    Called at application startup.

    Returns:
        Path to the config directory.
    """
    return get_config_dir()


# ---------------------------------------------------------------------------
# Config file (config.json) helpers
# ---------------------------------------------------------------------------

_CONFIG_FILE = "config.json"


def _config_path() -> Path:
    """Locate the main config file.

    Returns:
        Path of ``config.json`` in the config directory.
    """
    return get_config_dir() / _CONFIG_FILE


def load_config() -> dict[str, Any]:
    """Load the main config.json file.

    Returns:
        Parsed config dict, or empty dict if file doesn't exist or is invalid.
    """
    path = _config_path()
    if not path.is_file():
        logger.info("No config.json found at %s, returning empty config", path)
        return {}

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        logger.info("Loaded config from %s", path)
        return data
    except (json.JSONDecodeError, OSError) as e:
        log_error(str(e), source="config_dir.py:load_config")
        logger.warning("Failed to load config from %s: %s", path, e)
        return {}


def save_config(config: dict[str, Any]) -> bool:
    """Save the main config.json file.

    Args:
        config: Config dict to save.

    Returns:
        True on success, False on failure.
    """
    path = _config_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        logger.info("Saved config to %s", path)
        return True
    except OSError as e:
        log_error(str(e), source="config_dir.py:save_config")
        logger.warning("Failed to save config to %s: %s", path, e)
        return False


def get_mcp_config() -> dict[str, Any]:
    """Get the MCP section from config.json.

    Returns:
        Dict with 'timeout' and 'servers' keys, or empty dict if not configured.
    """
    config = load_config()
    return config.get("mcp", {})


def set_mcp_config(mcp_config: dict[str, Any]) -> bool:
    """Update the MCP section in config.json.

    Args:
        mcp_config: Dict with 'timeout' and 'servers' keys.

    Returns:
        True on success.
    """
    config = load_config()
    config["mcp"] = mcp_config
    return save_config(config)


# ---------------------------------------------------------------------------
# MCP JSON file (separate from main config.json)
# ---------------------------------------------------------------------------

_MCP_CONFIG_FILE = "mcp.json"


def _mcp_path() -> Path:
    """Locate the MCP config file.

    Returns:
        Path to ``~/.config/synapseForge/mcp.json``.
    """
    return get_config_dir() / _MCP_CONFIG_FILE


_MCP_CACHE: dict[str, Any] = {"path": None, "mtime": None, "size": None, "servers": []}
"""Cache of the last ``mcp.json`` read, keyed by path + mtime + size.

``load_mcp_servers`` runs on every MCP tool dispatch, so re-reading and
re-parsing the file each time is pure overhead. The path is part of the
key because tests (and multi-instance setups) point the config dir at
different folders; mtime alone could return another folder's data when
two files share the same timestamp tick. The cache returns copies, so
callers can mutate the result without corrupting it.
"""


def load_mcp_servers() -> list[dict[str, Any]]:
    """Load MCP servers from mcp.json (direct array).

    The file is only re-read when its path, mtime or size changed;
    otherwise a cached copy is returned. A missing or broken file yields
    ``[]`` (the reason is available via :func:`mcp_config_error`).

    Returns:
        List of MCP server config dicts, or empty list if file doesn't exist.
    """
    path = _mcp_path()
    if not path.is_file():
        _MCP_CACHE["path"] = None
        _MCP_CACHE["mtime"] = None
        _MCP_CACHE["size"] = None
        _MCP_CACHE["servers"] = []
        return []

    try:
        stat = path.stat()
        key = (str(path), stat.st_mtime_ns, stat.st_size)
    except OSError as e:
        log_error(str(e), source="config_dir.py:load_mcp_servers")
        return []
    if (
        key[0] == _MCP_CACHE["path"]
        and key[1] == _MCP_CACHE["mtime"]
        and key[2] == _MCP_CACHE["size"]
    ):
        return [dict(s) for s in _MCP_CACHE["servers"]]

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            logger.info("Loaded %d MCP server(s) from mcp.json", len(data))
            _MCP_CACHE["path"], _MCP_CACHE["mtime"], _MCP_CACHE["size"] = key
            _MCP_CACHE["servers"] = [s for s in data if isinstance(s, dict)]
            return [dict(s) for s in _MCP_CACHE["servers"]]
        logger.warning("mcp.json must be an array, got %s", type(data).__name__)
        return []
    except (json.JSONDecodeError, OSError) as e:
        log_error(str(e), source="config_dir.py:load_mcp_servers")
        logger.warning("Failed to load mcp.json: %s", e)
        return []


def mcp_config_error() -> str | None:
    """Return why ``mcp.json`` cannot be used, or ``None`` when it is fine.

    ``load_mcp_servers`` answers ``[]`` for a broken file, which looks like
    "no servers"; this tells the two cases apart (missing file is fine).

    Returns:
        A short error message, or ``None`` if the file is absent or a valid array.
    """
    path = _mcp_path()
    if not path.is_file():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        return f"mcp.json no es un JSON válido: {e}"
    if not isinstance(data, list):
        return "mcp.json debe ser un array de servidores."
    return None


def save_mcp_servers(servers: list[dict[str, Any]]) -> bool:
    """Save MCP servers to mcp.json.

    Writes to a temporary file in the same folder and replaces mcp.json in
    one step, so a crash mid-write never leaves a half-written file.

    Args:
        servers: List of MCP server config dicts.

    Returns:
        True on success.
    """
    path = _mcp_path()
    tmp_path = path.with_name(path.name + ".tmp")
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(servers, f, indent=2, ensure_ascii=False)
        os.replace(tmp_path, path)
        logger.info("Saved %d MCP server(s) to mcp.json", len(servers))
        # Invalidate the load cache so the next read sees the new file.
        _MCP_CACHE["path"] = None
        _MCP_CACHE["mtime"] = None
        _MCP_CACHE["size"] = None
        _MCP_CACHE["servers"] = []
        return True
    except OSError as e:
        log_error(str(e), source="config_dir.py:save_mcp_servers")
        return False


# ---------------------------------------------------------------------------
# Convenience paths for skills, tools, agents
# ---------------------------------------------------------------------------

def get_skills_dir() -> Path:
    """Locate the skills directory.

    Returns:
        Path of the skills directory.
    """
    return get_config_dir() / "skills"


def get_tools_dir() -> Path:
    """Locate the external tools directory.

    Returns:
        Path of the tools directory.
    """
    return get_config_dir() / "tools"


def get_agents_dir() -> Path:
    """Locate the agents directory.

    Returns:
        Path of the agents directory.
    """
    return get_config_dir() / "agents"


def get_workflows_dir() -> Path:
    """Locate the workflows directory, creating it if needed.

    Returns:
        Path of the workflows directory.
    """
    workflows_dir = get_config_dir() / "workflows"
    workflows_dir.mkdir(parents=True, exist_ok=True)
    return workflows_dir


def get_workflow_prompts_dir() -> Path:
    """Locate the directory with the prompts (toml) of the workflow agent nodes.

    Returns:
        Path of the prompts directory, created if needed.
    """
    prompts_dir = get_workflows_dir() / "prompts"
    prompts_dir.mkdir(parents=True, exist_ok=True)
    return prompts_dir


def get_knowledge_dir() -> Path:
    """Locate the knowledge (vector store) directory.

    Returns:
        Path of the knowledge directory.
    """
    return get_config_dir() / "knowledge"

# ---------------------------------------------------------------------------
# Workspace of the workflows
# ---------------------------------------------------------------------------


workspace_ctx: ContextVar[str | None] = ContextVar("workspace_ctx", default=None)
"""Working folder of the workflow being run; ``shell`` uses it when no ``workdir`` is given."""


def get_workspace_dir(name: str | None = None) -> Path:
    """Locate the working folder of a workflow, creating it if needed.

    Commands of a workflow (``git clone``, downloads, reports) run here, never
    in the project root: a clone inside the project triggers the dev server's
    reload and leaves the repo with files that are not its own.

    Args:
        name: Workflow name. ``None`` returns the parent folder.

    Returns:
        Path of the folder.
    """
    base = get_config_dir() / "workspace"
    if name:
        safe = "".join(c if c.isalnum() or c in "-_." else "_" for c in name).strip(".") or "workflow"
        base = base / safe
    base.mkdir(parents=True, exist_ok=True)
    return base
